[Firefox](https://addons.mozilla.org/en-GB/firefox/addon/github-widener/)
[Chrome]()

![](./screenshot.png)
